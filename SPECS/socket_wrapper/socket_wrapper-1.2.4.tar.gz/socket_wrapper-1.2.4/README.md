SOCKET_WRAPPER
==============

This is a library passing all socket communications through unix sockets.

DESCRIPTION
-----------

More details can be found in the manpage:

    man -l ./doc/socket_wrapper.1

or the raw text version:

    less ./doc/socket_wrapper.1.txt

For installation instructions please take a look at the README.install file.

MAILINGLIST
-----------

As the mailing list samba-technical is used and can be found here:

* https://lists.samba.org/mailman/listinfo/samba-technical
