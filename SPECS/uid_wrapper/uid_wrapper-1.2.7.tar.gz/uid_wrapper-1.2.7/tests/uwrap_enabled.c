#include <stdbool.h>

bool uid_wrapper_enabled(void);

bool uid_wrapper_enabled(void)
{
	return false;
}
